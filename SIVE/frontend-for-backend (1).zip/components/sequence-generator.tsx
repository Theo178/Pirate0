"use client";

import { useState } from "react";
import { Loader2, Layers, Copy, Check, Download } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { generateSequence, type SequenceShot } from "@/lib/api";

export function SequenceGenerator() {
  const [sceneText, setSceneText] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [sequence, setSequence] = useState<SequenceShot[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<number | null>(null);

  const handleGenerate = async () => {
    if (!sceneText.trim()) return;

    setIsGenerating(true);
    setError(null);

    try {
      const result = await generateSequence(sceneText);
      setSequence(result);
    } catch (err) {
      setError("Failed to generate sequence. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const copyPrompt = async (shot: SequenceShot) => {
    await navigator.clipboard.writeText(shot.prompt);
    setCopiedId(shot.shot_id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const downloadImage = async (shot: SequenceShot) => {
    try {
      const response = await fetch(shot.url);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `shot-${shot.shot_id}-${shot.type.toLowerCase().replace(/\s+/g, "-")}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Failed to download image:", err);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="border-border bg-card">
        <CardHeader className="pb-4">
          <CardTitle className="text-sm font-medium tracking-wide uppercase text-muted-foreground">
            Generate Full Sequence
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Describe your scene for the full shot sequence..."
            value={sceneText}
            onChange={(e) => setSceneText(e.target.value)}
            className="min-h-[150px] font-mono text-sm bg-input border-border resize-none"
          />
          <Button
            onClick={handleGenerate}
            disabled={isGenerating || !sceneText.trim()}
            className="w-full"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Generating Sequence (this may take a while)...
              </>
            ) : (
              <>
                <Layers className="w-4 h-4 mr-2" />
                Generate Full Sequence
              </>
            )}
          </Button>
          {error && <p className="text-sm text-destructive">{error}</p>}
        </CardContent>
      </Card>

      {sequence.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium tracking-wide uppercase text-muted-foreground">
              Shot Sequence ({sequence.length} shots)
            </h3>
          </div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {sequence.map((shot) => (
              <Card key={shot.shot_id} className="border-border bg-card overflow-hidden">
                <div className="relative aspect-video bg-accent">
                  <img
                    src={shot.url || "/placeholder.svg"}
                    alt={`Shot ${shot.shot_id}: ${shot.type}`}
                    className="w-full h-full object-cover"
                    crossOrigin="anonymous"
                  />
                  <div className="absolute top-2 left-2 px-2 py-1 bg-background/80 backdrop-blur-sm rounded text-xs font-mono">
                    #{shot.shot_id}
                  </div>
                </div>
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{shot.type}</span>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyPrompt(shot)}
                        className="h-8 w-8 p-0"
                      >
                        {copiedId === shot.shot_id ? (
                          <Check className="w-3 h-3" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => downloadImage(shot)}
                        className="h-8 w-8 p-0"
                      >
                        <Download className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-3 font-mono">
                    {shot.prompt}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
