"use client";

import { useEffect, useState } from "react";
import { Circle, CheckCircle2, XCircle } from "lucide-react";
import { checkHealth } from "@/lib/api";

export function StatusIndicator() {
  const [status, setStatus] = useState<"checking" | "online" | "offline">("checking");

  useEffect(() => {
    const check = async () => {
      try {
        await checkHealth();
        setStatus("online");
      } catch {
        setStatus("offline");
      }
    };

    check();
    const interval = setInterval(check, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex items-center gap-2 text-xs">
      {status === "checking" && (
        <>
          <Circle className="w-3 h-3 text-muted-foreground animate-pulse" />
          <span className="text-muted-foreground">Checking...</span>
        </>
      )}
      {status === "online" && (
        <>
          <CheckCircle2 className="w-3 h-3 text-foreground" />
          <span className="text-muted-foreground">Backend Online</span>
        </>
      )}
      {status === "offline" && (
        <>
          <XCircle className="w-3 h-3 text-destructive" />
          <span className="text-destructive">Backend Offline</span>
        </>
      )}
    </div>
  );
}
